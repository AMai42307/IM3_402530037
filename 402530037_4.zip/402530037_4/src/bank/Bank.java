package bank;
import java.util.ArrayList;

public class Bank {

	//��U�ӱb�᪺��Ʀ����_��
	ArrayList <BankAccount>bankaclist= new ArrayList();

	public int Search(int accountNumber){
		for(int i=0;i<bankaclist.size();i++){
			if(bankaclist.get(i).accountnumber==accountNumber){
				return i;
			}
		}return -1;
	}
	
	public boolean checkAccount(int accountNumber){
		for(int i=0;i<bankaclist.size();i++){
			if(bankaclist.get(i).accountnumber==accountNumber){
				return true;//�b��w�s�b
			}
		}return false;//�b�ᤣ�s�b
	}


	//�ˬd�O�_�����ƪ��b��
	
	public void addAccount(int accountNumber, double initialBalance){

		//�ˬd�O�_���w�s�b�b��
		if(checkAccount(accountNumber)==false){
			BankAccount s= new BankAccount(accountNumber, initialBalance);
			bankaclist.add(s);
			//��J�b����
		}
		else{
			System.out.println("���b��w�s�b�A����}�ҷs�b��C\n");
			//���s�b�b��A�}�ᥢ��
		}
		
		
	}
	
	public void deposit(int accountNumber, double initialBalance){
		bankaclist.get(Search(accountNumber)).deposit(initialBalance);
	}//�s��
	
	public void withdraw(int accountNumber, double initialBalance){
		bankaclist.get(Search(accountNumber)).withdraw(initialBalance);
	}
	public double getBalance(int accountNumber){
		return bankaclist.get(Search(accountNumber)).getbalance();
	}
	public void suspendAccount(int accountNumber){
		bankaclist.get(Search(accountNumber)).suspend();
	}
	public void reOpenAccount(int accountNumber){
		bankaclist.get(Search(accountNumber)).reOpen();
	}
	public void closeAccount(int accountNumber){
		bankaclist.get(Search(accountNumber)).close();
	}
	public String getAccountStatus(int accountNumber){
		return bankaclist.get(Search(accountNumber)).getStatus();
	}
	public String summarizeAccountTransactions(int accountNumber){
		return bankaclist.get(Search(accountNumber)).getTransactions();
	}
	public String summarizeAllAccounts(){
		String answer="";
		answer+="Bank Account Summary\n"
		+"Account  Balance  #Transactions  Status \n";
		for(int i=0;i<bankaclist.size();i++){
			answer+=bankaclist.get(i).accountnumber+"     "+bankaclist.get(i).getbalance()+"       "
					+bankaclist.get(i).retrieveNumberOfTransactions()+"             "
					+bankaclist.get(i).getStatus()+"\n";
		}
		return answer;
	}
}
