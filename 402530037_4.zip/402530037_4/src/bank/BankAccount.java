package bank;
import java.util.ArrayList;

public class BankAccount {

	String state;//�b�᪬�A ����open,suspended,closed�T��
	int accountnumber;//�b��s�X
	private double balance;//�{�����B
	private ArrayList <Double> transactionlist=new ArrayList();//�������
	
	public BankAccount(){
		
	}
	
	public BankAccount(int acnumber){
		accountnumber=acnumber;
		balance=0;
		state="open";
	}
	
	public BankAccount(int acnumber,double bal){
		accountnumber=acnumber;
		balance=bal;
		state="open";
	}
	
	boolean isOpen() {
		return state.equals("open");//�T�{�O�_���}�Ҫ��A
	}
	boolean isSuspended() {
		return state.equals("suspended");//������
	}
	boolean isClosed(){
		return state.equals("closed");
	}

	void suspend(){
		state="suspended";
	}
	void close(){

		state="closed";
	}
	void reOpen() {
		state="open";
	}

	void deposit(double amount) {
		if(this.isOpen()&&balance>=0){
			balance+=amount;
			this.addTransaction(amount);//�s��
		}
	}

	void withdraw(double amount) {
		if(this.isOpen()&&balance>0&&amount<=balance){
			balance-=amount;
			addTransaction(-1*amount);//����
			}
		
	}

	void addTransaction(double amount) {
		transactionlist.add(amount);
	}

	String getTransactions() {
		String result="";
		result+="Account #"+accountnumber+" transactions:\n";
		for(int i=0;i<transactionlist.size();i++){
			result+=(i+1)+": "+transactionlist.get(i)+"\n";
		}
		result+="End of transactions\n";
		return result;
	}//��X���G�r��

	int retrieveNumberOfTransactions() {
		return transactionlist.size();

	}
	double getbalance(){
		return balance;
	}
	String getStatus(){
		return state;
	}
}
